// server.js
const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const WebSocket = require('ws');

const app = express();
app.use(cors());

const pool = mysql.createPool({
    connectionLimit: 10,
    port: 3304,
    host: 'localhost',
    user: 'root',
    password: '123456789',
    database: 'grafo',
    insecureAuth: true
});

const server = app.listen(3001, () => {
    console.log('Server running on port 3001');
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    console.log('Client connected');
    
    // Send initial graph data to client
    sendGraphData(ws);

    // Listen for database changes and send updates to clients
    pool.on('update', () => {
        sendGraphData(ws);
    });
});

function sendGraphData(ws) {
    const nodesQuery = 'SELECT id, label, value FROM nodos';
    const edgesQuery = 'SELECT from_node AS `from`, to_node AS `to`, value FROM aristas';

    pool.query(nodesQuery, (err, nodes) => {
        if (err) throw err;
        pool.query(edgesQuery, (err, edges) => {
            if (err) throw err;
            const graphData = { nodes, edges };
            ws.send(JSON.stringify(graphData));
        });
    });
}
