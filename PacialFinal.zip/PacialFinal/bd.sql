CREATE DATABASE grafo;

USE grafo;

CREATE TABLE nodos (
    id INT PRIMARY KEY,
    label VARCHAR(255) NOT NULL,
    value INT
);

CREATE TABLE aristas (
    id INT PRIMARY KEY AUTO_INCREMENT,
    from_node INT,
    to_node INT,
    value INT,
    FOREIGN KEY (from_node) REFERENCES nodos(id),
    FOREIGN KEY (to_node) REFERENCES nodos(id)
);

INSERT INTO nodos (id, label, value) VALUES
(1, 'Areas', 300),
(2, 'Matematicas', 150),
(3, 'Geometria', 10),
(4, 'Algebra', 10),
(5, 'Calculo', 10),
(6, 'Filosofia', 150),
(7, 'Etica', 10),
(8, 'Logica', 10),
(9, 'Filosofia de Mente', 10),
(10, 'Ciencias', 150),
(11, 'Fisica', 10),
(12, 'Integral', 10);

INSERT INTO aristas (from_node, to_node, value) VALUES
(1, 2, 2),
(1, 6, 2),
(1, 10, 2),
(2, 3, 2),
(2, 4, 2),
(2, 5, 2),
(5, 12, 2),
(6, 7, 2),
(6, 8, 2),
(6, 9, 2),
(10, 11, 2),
(10, 2, 2);
